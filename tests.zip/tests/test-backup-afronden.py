"""Backupmelding volgt de drempels, ook na het AFRONDEN van een ronde.

Sinds 0EF telt een helemaal ingevulde ronde al mee terwijl hij open staat (Marks keuze);
de situatie hieronder begint daarom met een backup van vóór het spelen.

Aanleiding (Marks melding): backup 5 dagen geleden, drempels op 1 dag en 1 wijziging,
een nieuwe ronde gespeeld — en toch een GRIJZE regel en geen stip. Oorzaak: de ronde
die je speelt zit niet in de backup; bij het afronden werd hij alleen losgelaten als
actieve ronde, zonder dat de rondelijst opnieuw werd geschreven. Dan kwam er geen
wijzigingsstempel, en de controle voor oranje keek alleen naar dat stempel.

Gecontroleerd via de ECHTE routes: een actieve ronde wordt bij het laden hersteld,
en daarna afgerond met finishActiveRound, saveAndClearActiveRound of clearActiveRound.
"""
import asyncio, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from testdata import CLUBS, RONDES, app_url, SEED
from playwright.async_api import async_playwright

fouten = []
def check(naam, echt, verwacht):
    ok = echt == verwacht
    print(f"  {'ok  ' if ok else 'FOUT'} {naam}: {echt}" + ('' if ok else f" — verwacht {verwacht}"))
    if not ok: fouten.append(naam)

# Backup van 5 dagen geleden, alles veilig. Daarna een ronde als ACTIEVE ronde in de
# lijst zetten (zoals saveActiveRound dat doet) en de pagina herladen, zodat de app hem
# zelf als lopende ronde herstelt. compleet=False: de ronde is nog niet uitgespeeld.
OPZET = """async ([compleet, dagenDrempel, rondesDrempel]) => {
  localStorage.setItem('golf_backup_reminder_days', String(dagenDrempel));
  localStorage.setItem('golf_backup_reminder_rounds', String(rondesDrempel));
  await exportAllClubs();                       // clubs veilig: de stip gaat alleen over rondes
  // Eerst de backup (vóór het spelen), dan pas de ronde. Sinds 0EF telt een helemaal
  // ingevulde ronde ook mee als hij open staat; een backup ná het klaarzetten zou hem
  // dus al bevatten.
  const d = new Date(); d.setDate(d.getDate() - 5);
  const dISO = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  localStorage.setItem('golf_last_backup_date', dISO);
  localStorage.setItem('golf_last_backup_ts', d.toISOString());
  localStorage.setItem('golf_last_backup_count', String(afgerondeRondesCount()));
  localStorage.setItem('golf_backup_fingerprint', backupVingerafdruk());
  localStorage.setItem('golf_backup_fp_bij_backup', backupVingerafdruk());
  localStorage.setItem('golf_rounds_changed', new Date(d.getTime() - 60000).toISOString());
  const lijst = loadSavedRounds();
  const basis = lijst.find(r => (r.holes || []).length && r.holes.every(h => h.score !== null));
  const nieuw = { ...basis, id: 990001, date: todayISO(), time: '07:00',
                  holes: basis.holes.map((h, i) => ({ ...h, score: (compleet || i < 3) ? h.score : null })) };
  localStorage.setItem('golf_active_id', '990001');
  lijst.unshift(nieuw);
  metVerwijderen(() => setRoundsAndMark(JSON.stringify(lijst)));
}"""

STAND = """() => {
  nav('settings'); updateLastBackupDisplay();
  const regel = document.getElementById('newRoundsInfoTop');
  return {
    actief: !!localStorage.getItem('golf_active_id'),
    regel: regel.classList.contains('hidden') ? 'geen' :
           (regel.innerHTML.includes('--orange') ? 'oranje' : 'grijs'),
    stip: document.getElementById('tab-settings').classList.contains('has-dot'),
  };
}"""

async def opzetten(page, compleet=True, dagen=1, rondes=1):
    await page.goto(app_url()); await page.evaluate(SEED, [CLUBS, RONDES])
    await page.reload(); await page.wait_for_timeout(500)
    await page.evaluate(OPZET, [compleet, dagen, rondes])
    await page.reload(); await page.wait_for_timeout(600)
    return await page.evaluate("() => ({ hersteld: game.started === true && String(game.id) === '990001' })")

async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch()
        page = await b.new_page(viewport={'width': 390, 'height': 780})
        pagina_fouten = []
        page.on('pageerror', lambda e: pagina_fouten.append(str(e)[:120]))

        print("\n=== 1. MARKS SITUATIE: AFRONDEN MET DE KNOP ===\n")
        h = await opzetten(page)
        check("de ronde loopt na herladen", h['hersteld'], True)
        s = await page.evaluate(STAND)
        # Sinds 0EF (Marks keuze): een helemaal ingevulde ronde hoort in de backup, ook
        # als hij nog open staat. Dus al vóór het afronden oranje.
        check("alle holes ingevuld, nog open: al oranje (hoort in de backup)",
              (s['regel'], s['stip']), ('oranje', True))
        await page.evaluate("() => finishActiveRound(null)")
        await page.wait_for_timeout(150)
        s = await page.evaluate(STAND)
        check("afgerond: geen actieve ronde meer", s['actief'], False)
        check("drempel 1 dag / 1 ronde gehaald: oranje", s['regel'], 'oranje')
        check("en de stip op het tandwiel", s['stip'], True)

        print("\n=== 2. AFRONDEN VIA 'OPSLAAN EN SLUITEN' IN RONDES ===\n")
        await opzetten(page)
        # De echte knop in Rondes, twee tikken (de tweede bevestigt).
        await page.evaluate("() => nav('archive')")
        await page.wait_for_timeout(300)
        knop = page.locator('button[data-round-id="990001"][onclick^="saveAndClearActiveRound"]').first
        check("de knop 'Gereed' staat in Rondes", await knop.count() > 0, True)
        await knop.click(); await page.wait_for_timeout(100)
        await knop.click(); await page.wait_for_timeout(250)
        s = await page.evaluate(STAND)
        check("oranje", s['regel'], 'oranje')
        check("stip", s['stip'], True)

        print("\n=== 3. AFRONDEN VIA clearActiveRound ===\n")
        await opzetten(page)
        await page.evaluate("() => clearActiveRound()")
        await page.wait_for_timeout(150)
        s = await page.evaluate(STAND)
        check("oranje", s['regel'], 'oranje')
        check("stip", s['stip'], True)

        print("\n=== 4. EEN ONAFGEMAAKTE RONDE LOSLATEN GEEFT GEEN MELDING ===\n")
        await opzetten(page, compleet=False)
        await page.evaluate("() => clearActiveRound()")
        await page.wait_for_timeout(150)
        s = await page.evaluate(STAND)
        check("geen regel (niets nieuws in de backup)", s['regel'], 'geen')
        check("geen stip", s['stip'], False)
        gestempeld = await page.evaluate(
            "() => localStorage.getItem('golf_rounds_changed') > localStorage.getItem('golf_last_backup_ts')")
        check("en geen stempel", gestempeld, False)

        print("\n=== 5. DREMPELS NIET GEHAALD: GRIJS, GEEN STIP ===\n")
        # 1 nieuwe ronde, drempel 2 rondes, backup 5 dagen oud, dagendrempel 30.
        await opzetten(page, dagen=30, rondes=2)
        await page.evaluate("() => finishActiveRound(null)")
        await page.wait_for_timeout(150)
        s = await page.evaluate(STAND)
        check("grijs", s['regel'], 'grijs')
        check("geen stip", s['stip'], False)

        print("\n=== 6. NIEUWE RONDE ZONDER STEMPEL (OUDE STAND) TELT TOCH ===\n")
        # Zo stonden installaties die al een ronde afrondden vóór deze correctie.
        await opzetten(page)
        # Oude installatie: nog geen vastgelegde backupinhoud, dus de terugval op tijdstip.
        r = await page.evaluate("""() => {
            localStorage.removeItem('golf_backup_fp_bij_backup');
            localStorage.removeItem('golf_active_id');   // losgelaten zonder stempel
            return { nieuw: isErIetsOnveiligs(), overdue: isBackupOverdue() };
        }""")
        check("de grijze regel en de dringende stand zijn het eens", (r['nieuw'], r['overdue']), (True, True))

        print("\n=== 7. EEN RONDE STARTEN GEEFT GEEN STEMPEL ===\n")
        await opzetten(page, compleet=False)
        r = await page.evaluate("""() => {
            const voor = localStorage.getItem('golf_rounds_changed');
            saveActiveRound(true);                       // schrijven tijdens het spelen
            return localStorage.getItem('golf_rounds_changed') === voor;
        }""")
        check("stempel ongewijzigd tijdens het spelen", r, True)

        check("geen fouten in de pagina", pagina_fouten, [])
        await b.close()

    print()
    print("GEEN FOUTEN" if not fouten else f"{len(fouten)} FOUT(EN)")

asyncio.run(main())
