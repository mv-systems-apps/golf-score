#!/usr/bin/env python3
"""Draait alle controles en tests en geeft één samenvatting.

Gebruik:
    python3 tests/run-alles.py                 # tegen ../golf-score.html
    APP=/pad/naar/golf-score.html python3 tests/run-alles.py

Eerst de snelle statische controles (node), dan de browsertests (playwright).
Stopt nergens: je krijgt altijd het volledige beeld.
"""
import os, re, subprocess, sys, time

HIER = os.path.dirname(os.path.abspath(__file__))
APP = os.environ.get('APP') or os.path.join(os.path.dirname(HIER), 'golf-score.html')

STATISCH = [
    ('controle-diep.js',         'syntax, dode code, losse eindjes'),
    ('controle-baanmodel.js',    'par en SI horen bij de tee'),
    ('controle-breed.js',        'app-brede samenhang'),
    ('controle-herplan.js',      'opnieuw plannen'),
    ('controle-filter-putts.js', 'filters en puttregels'),
    ('controle-hernoemen.js',    'clubs/banen/tees hernoemen'),
    ('controle-inlezen.js',      'foutafvang bij inlezen', True),
    ('test-duplicaat.js',        'duplicaten en koppeling speler 2'),
    ('test-isaf.js',             '"is deze ronde af" — randgevallen'),
    ('test-afgerond.js',         'de manieren om "afgerond" te bepalen', True),
]

BROWSER = [
    ('ijk-stats.py',            'statistieken byte-voor-byte (ijkmeting)', ['ijkmeting.json']),
    ('test-herplan-browser.py', 'opnieuw plannen, end-to-end', []),
    ('test-modals.py',          'de twee bewerkvensters', []),
    ('test-corrupt.py',         'corrupte gegevens worden niet overschreven', []),
    ('test-backupteller.py',    'backupwaarschuwing telt afgeronde rondes', []),
    ('test-tellerlag.py',       'telling klopt tijdens het spelen', []),
    ('test-paden.py',           'alle schermen en verse installatie', []),
    ('test-labels.py',          'labels bij de invoervelden', []),
    ('test-autonext.py',        'automatisch naar de volgende hole', []),
    ('test-instellingen.py',    'secties ingeklapt en backupregel bovenaan', []),
    ('test-instellingen2.py',   'tabnamen, lang indrukken, tik op de status', []),
    ('test-backupblok.py',      'backupblok bovenaan en de sprong naar Backup', []),
    ('test-backupinfo.py',      'backupstand bijgewerkt via alle acht routes', []),
    ('test-notitie-start.py',   'notitie op het startscherm en bij herplannen', []),
    ('test-cr-grenzen.py',      'CR-grenzen volgen het aantal holes', []),
    ('test-gewijzigd.py',       'gewijzigd-stempel volgt de backupinhoud', []),
    ('test-par-per-tee.py',     'par en SI per tee, van editor tot ronde', []),
    ('test-levenscyclus.py',    'baan maken, spelen, backuppen, herstellen', []),
    ('test-editor-stress.py',   'baaneditor onder druk (60 bewerkingen)', []),
    ('test-herplan-startscherm.py', 'herplannen vult het startscherm volledig', []),
    ('test-rode-knoppen.py',     'wit op rood, ook pictogrammen', []),
    ('test-volgende-hole.py',    'doorspringen naar de volgende lege hole', []),
    ('test-rondeverlies.py',     'een ingevulde kaart raakt niet zoek', []),
    ('test-opslagcode.py',       'welke opslag is dit (profiel/adres)', []),
    ('test-updatebanner.py',     'versiebanner wijst de juiste kant op', []),
    ('test-langindrukken.py',    'lang indrukken is overal een toggle', []),
    ('test-clubbackup.py',       'backupherinnering voor clubs', []),
    ('test-teevolgorde.py',      'tees overal in dezelfde volgorde', []),
    ('test-rondescache.py',      'bewaarde rondelijst: snel en veilig', []),
    ('test-doorloop.py',         'hele keten met echte tikken, twee spelers', []),
    ('test-restpaden.py',        'import, 18 holes, speler 2, club tijdens ronde', []),
    ('test-opslagstoring.py',    'opslag weigert halverwege een ronde', []),
    ('test-naamswijziging.py',   'naam wijzigen raakt je handicap niet stil', []),
    ('test-kopuitlijning.py',    'groepskoppen precies gelijk uitgelijnd', []),
    ('test-lijstgrens.py',       'gegroepeerde lijsten blijven begrensd', []),
    ('test-whsvolgen.py',        'handicap bijhouden aan/uit', []),
    ('test-lowhi-regel.py',      'Low HI-regel is aanklikbaar', []),
    ('test-watals.py',           'Wat als klopt met de vooruitblik', []),
    ('test-spelergroepen.py',    'geplande rondes apart per speler', []),
    ('test-wedstrijdpercentage.py','wedstrijdpercentage op de baanhandicap', []),
    ('test-actief-corrigeren.py', 'actieve ronde corrigeren zonder valse melding', []),
    ('test-notitie-behoud.py',   'notitie overleeft het hervatten', []),
    ('test-per-negen.py',        'per negen in de ronde-informatie', []),
    ('test-lowhi-per-ronde.py',  'Low HI per ronde, niet die van vandaag', []),
    ('test-wanneer-best.py',     'wanneer speel je het best (dag, maand, kwartaal)', []),
    ('test-corrigeren.py',       'gespeelde ronde corrigeren met behoud van scores', []),
    ('test-waarschuwingsdriehoek.py', 'driehoekje bij afgeleide waarden', []),
    ('meet-prestaties.py',      'snelheid per scherm', [], True),
]

def kop(t):
    print('\n' + t)
    print('─' * len(t))

def draai(cmd, naam, omschrijving, meting=False):
    t0 = time.time()
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=420,
                           cwd=HIER, env={**os.environ, 'APP': APP})
        uitvoer = (r.stdout or '').strip()
        crash = r.returncode != 0 and 'Traceback' in (r.stderr or '')
    except subprocess.TimeoutExpired:
        uitvoer, crash = 'TIJD VERSTREKEN', True
    except Exception as e:
        uitvoer, crash = 'FOUT: ' + str(e)[:60], True

    regels = [x.strip() for x in uitvoer.split('\n') if x.strip()]
    laatste = regels[-1] if regels else '(geen uitvoer)'

    # Oordeel op de HELE uitvoer: eerst kijken of er ergens een fout gemeld wordt.
    tekst = uitvoer.lower()
    faalt = (crash or not regels
             or re.search(r'\b\d+ fout\(en\)', tekst)
             or ' fout ' in tekst or 'afwijking' in tekst
             or 'verschil gevonden' in tekst or 'syntaxfout' in tekst
             or 'traceback' in tekst)
    slaagt = any(w in tekst for w in
                 ['geen fouten', 'geslaagd', 'identiek', "alle scenario's goed",
                  'gevallen goed', 'ongewijzigd', 'afwijkingen: 0', 'fouten onderweg: geen'])

    if meting:
        merk, oordeel = '    ', 'meting'
    elif faalt and not slaagt:
        merk, oordeel = ' !! ', 'PROBLEEM'
    elif slaagt:
        merk, oordeel = '    ', 'goed'
    else:
        merk, oordeel = '  ? ', 'onduidelijk'

    sec = f'{time.time() - t0:4.1f}s'
    print(f'{merk}{naam:<26}{sec}  {oordeel:<10} {omschrijving}')
    print(f'      → {laatste[:94]}')
    return meting or (slaagt and not faalt)

def main():
    if not os.path.exists(APP):
        print('App niet gevonden: ' + APP)
        print('Geef het pad mee met APP=/pad/naar/golf-score.html')
        sys.exit(1)
    print('App: ' + APP)
    goed = []

    kop('STATISCHE CONTROLES')
    for regel in STATISCH:
        naam, oms = regel[0], regel[1]
        meting = len(regel) > 2 and regel[2]
        if os.path.exists(os.path.join(HIER, naam)):
            goed.append(draai(['node', naam], naam, oms, meting))

    kop('BROWSERTESTS')
    for regel in BROWSER:
        naam, oms, extra = regel[0], regel[1], regel[2]
        meting = len(regel) > 3 and regel[3]
        if os.path.exists(os.path.join(HIER, naam)):
            goed.append(draai(['python3', naam] + ([APP] + extra if extra else []), naam, oms, meting))

    if os.path.exists(os.path.join(HIER, 'rondes_backup.json')):
        kop('MET JE EIGEN BACKUP')
        goed.append(draai(['python3', 'test-herstel.py'], 'test-herstel.py',
                          'backup terugzetten en vergelijken'))

    kop('SAMENVATTING')
    aantal = len([g for g in goed if g is not None])
    print(f'  {sum(1 for g in goed if g)} van de {aantal} onderdelen goed of gemeten')
    if not all(goed):
        print('  Kijk hierboven bij de regels met !! of ?')
    else:
        print('  Alles in orde.')
    sys.exit(0 if all(goed) else 1)

if __name__ == '__main__':
    main()
